﻿Imports System.Text.RegularExpressions

Public Class Form1

    Private Sub MyCheckBoxCheckedHandler(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox4.CheckedChanged, CheckBox3.CheckedChanged, CheckBox2.CheckedChanged, CheckBox1.CheckedChanged, CheckBox5.CheckedChanged, CheckBox6.CheckedChanged, CheckBox7.CheckedChanged, CheckBox8.CheckedChanged

        Dim cb1 As CheckBox = CType(sender, CheckBox)

        Dim checked As Boolean = cb1.Checked

        Select Case cb1.Name

            Case "CheckBox1"
                CheckBox2.Checked = False
                CheckBox3.Checked = False
                CheckBox4.Checked = False

            Case "CheckBox2"
                CheckBox1.Checked = False
                CheckBox3.Checked = False
                CheckBox4.Checked = False

            Case "CheckBox3"
                CheckBox1.Checked = False
                CheckBox2.Checked = False
                CheckBox4.Checked = False

            Case "CheckBox4"
                CheckBox1.Checked = False
                CheckBox2.Checked = False
                CheckBox3.Checked = False

        End Select


        Select Case cb1.Name

            Case "CheckBox5"
                CheckBox6.Checked = False
                CheckBox7.Checked = False
                CheckBox8.Checked = False

            Case "CheckBox6"
                CheckBox5.Checked = False
                CheckBox7.Checked = False
                CheckBox8.Checked = False

            Case "CheckBox7"
                CheckBox5.Checked = False
                CheckBox6.Checked = False
                CheckBox8.Checked = False

            Case "CheckBox8"
                CheckBox5.Checked = False
                CheckBox6.Checked = False
                CheckBox7.Checked = False

        End Select

    End Sub

    Private Sub MyTextBoxInputHandler(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged, TextBox2.TextChanged

        Regex.Replace(TextBox1.Text, "[^\d]", " ")
        Regex.Replace(TextBox2.Text, "[^\d]", " ")

    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim numberCheckedas As Integer = 0


        'Add array here for checkboxes to throw error message when more then one is clicked or whatever. Also after button 2 click


        Dim Box11 As Integer
        Dim Box12 As Integer
        Dim Box13 As Integer
        Dim Box14 As Integer
        Dim Box15 As Integer
        Dim Box16 As Integer
        Dim box17 As Integer
        Dim box18 As Integer



        'Check to see if unit are seconds

        'HAS TO BE REDONE
        If CheckBox1.Checked = True Then


            'SECONDS:

            'LABEL8

            'get numbers from textbox1
            Box11 = TextBox1.Text
            'print numbers to label8
            Label8.Text = Box11

            'LABEL9

            'get numbers from textbox1
            Box12 = TextBox1.Text
            'do calculations for label9
            Box12 = (Box12 * 30)
            'print numbers to label9
            Label9.Text = Box12


            'MINUTES:

            'LABEL12

            'get numbers from textbox1
            Box13 = TextBox1.Text
            'do calculations for label12
            Box13 = (Box13 / 60)
            'print numbers to label12
            Label12.Text = Box13

            'LABEL13

            'get numbers from textbox1
            Box14 = TextBox1.Text
            'do calculations for label13
            Box14 = (Box14 * (1 / 2))
            'print numbers to label13
            Label13.Text = Box14


            'HOURS

            'LABEL16

            'get numbers from textbox1
            Box15 = TextBox1.Text
            'do calculations for label16
            Box15 = (Box15 / (60 * 60))
            'print numbers to label 16
            Label16.Text = Box15

            'LABEL17

            'get numbers from textbox1
            Box16 = TextBox1.Text
            'do calculations for label17
            Box16 = (Box16 * (1 / 120))
            'print numbers to label17
            Label17.Text = Box16


            'DAYS:

            'LABEL20

            'get numbers from textbox1
            box17 = TextBox1.Text
            'do calculations for label17
            box17 = (box17 / 86400)
            'print numbers to label17
            Label20.Text = box17

            'LABEL21

            'get numbers from textbox1
            box18 = TextBox1.Text
            'do calculations for label17
            box18 = (box18 * (1 / 2880))
            'print numbers to label17
            Label21.Text = box18

        End If

        Dim Box21 As Integer
        Dim Box22 As Integer
        Dim Box23 As Integer
        Dim Box24 As Integer
        Dim Box25 As Integer
        Dim Box26 As Integer
        Dim Box27 As Integer
        Dim Box28 As Integer

        'check to see if units are minutes
        If CheckBox2.Checked = True Then

            'SECONDS

            'LABEL8

            'get numbers from textbox1
            Box21 = TextBox1.Text
            'do calculations for label8
            Box21 = Box21 * 60
            'print numbers to label8
            Label8.Text = Box21

            'LABEL9

            'get numbers from textbox1
            Box22 = TextBox1.Text
            'do calculations for label9
            Box22 = Box22 * 1800
            'print numbers to label9
            Label9.Text = Box22

            'MINUTES:

            'LABEL12

            'get numbers from textbox1
            Box23 = TextBox1.Text
            'print numbers to label12
            Label12.Text = Box23

            'LABEL13

            'get numbers from textbox1
            Box24 = TextBox1.Text
            'do calculations for label13
            Box24 = Box24 * 30
            'print numbers to label13
            Label13.Text = Box24

            'HOURS:

            'LABEL16

            'get numbers from textbox1
            Box25 = TextBox1.Text
            'do calculations for label16
            Box25 = Box25 / 60
            'print numbers to label16
            Label16.Text = Box25

            'LABEL17

            'get numbers from textbox1
            Box26 = TextBox1.Text
            'do calculations for label17
            Box26 = Box26 * (1 / 2)
            'print numbers to label17
            Label17.Text = Box26

            'DAYS:

            'LABEL20

            'get numbers from textbox1
            Box27 = TextBox1.Text
            'do calculations for label20
            Box27 = Box27 / (60 * 24)
            'print numbers to label20
            Label20.Text = Box27

            'LABEL21

            'get numbers from textbox1
            Box28 = TextBox1.Text
            'do calculations for label21
            Box28 = Box28 / 48
            'print numbers to label21
            Label21.Text = Box28

        End If

        Dim Box31 As Integer
        Dim Box32 As Integer
        Dim Box33 As Integer
        Dim Box34 As Integer
        Dim Box35 As Integer
        Dim Box36 As Integer
        Dim Box37 As Integer
        Dim Box38 As Integer

        'check to see if units are hours
        If CheckBox3.Checked = True Then

            'SECONDS:

            'LABEL8

            'get numbers from textbox1
            Box31 = TextBox1.Text
            'do calculations for label8
            Box31 = Box31 * (60 * 60)
            'print numbers to label8
            Label8.Text = Box31

            'LABEL9

            'get numbers from textbox1
            Box32 = TextBox1.Text
            'do calculations for label9
            Box32 = Box32 * 108000
            'print numbers to label9
            Label9.Text = Box32

            'MINUTES:

            'LABEL12

            'get numbers from textbox1
            Box33 = TextBox1.Text
            'do calculations for label12
            Box33 = Box33 * 60
            'print numbers to label12
            Label12.Text = Box33

            'LABEL13

            'get numbers from textbox1
            Box34 = TextBox1.Text
            'do calculations for label13
            Box34 = Box34 * 1800
            'print numbers to label13
            Label13.Text = Box34

            'HOURS:

            'LABEL16

            'get numbers from textbox1
            Box35 = TextBox1.Text
            'do calculations for label16
            '
            'print numbers to label16
            Label16.Text = Box35

            'LABEL17

            'get numbers from textbox1
            Box36 = TextBox1.Text
            'do calculations for label17
            Box36 = Box36 * 30
            'print numbers to label17
            Label17.Text = Box36

            'DAYS:

            'LABEL20

            'get numbers from textbox1
            Box37 = TextBox1.Text
            'do calculations for label20
            Box37 = Box37 / 24
            'print numbers to label20
            Label20.Text = Box37

            'LABEL21

            'get numbers from textbox1
            Box38 = TextBox1.Text
            'do calculations for label21
            Box38 = Box38 * 1.25
            'print numbers to label21
            Label21.Text = Box38
        End If

        Dim Box41 As Integer
        Dim Box42 As Integer
        Dim Box43 As Integer
        Dim Box44 As Integer
        Dim Box45 As Integer
        Dim Box46 As Integer
        Dim Box47 As Integer
        Dim Box48 As Integer

        'check to see if units are days
        If CheckBox4.Checked = True Then

            'SECONDS:

            'LABEL8

            'get numbers from textbox1
            Box41 = TextBox1.Text
            'do calculations for label8
            Box41 = Box41 * (24 * 60 * 60)
            'print numbers to label8
            Label8.Text = Box41

            'LABEL9

            'get numbers from textbox1
            Box42 = TextBox1.Text
            'do calculations for label9
            Box42 = Box42 * 2592000
            'print numbers to label9
            Label9.Text = Box42

            'HMINUTES:

            'LABEL12

            'get numbers from textbox1
            Box43 = TextBox1.Text
            'do calculations for label12
            Box43 = Box43 * (24 * 60)
            'print numbers to label12
            Label12.Text = Box43

            'LABEL13

            'get numbers from textbox1
            Box44 = TextBox1.Text
            'do calculations for label13
            Box44 = Box44 * 43200
            'print numbers to label13
            Label13.Text = Box44

            'HOURS:

            'LABEL16

            'get numbers from textbox1
            Box45 = TextBox1.Text
            'do calculations for label16
            Box45 = Box45 * 24
            'print numbers to label16
            Label16.Text = Box45

            'LABEL17

            'get numbers from textbox1
            Box46 = TextBox1.Text
            'do calculations for label17
            Box46 = Box46 * 720
            'print numbers to label17
            Label17.Text = Box46

            'DAYS:

            'LABEL20

            'get numbers from textbox1
            Box47 = TextBox1.Text
            'do calculations for label20
            '
            'print numbers to label20
            Label20.Text = Box47

            'LABEL21

            'get numbers from textbox1
            Box48 = TextBox1.Text
            'do calculations for label21
            Box48 = Box48 * 30
            'print numbers to label21
            Label21.Text = Box48

        End If


    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Dim Box51 As Integer
        Dim Box52 As Integer
        Dim Box53 As Integer
        Dim Box54 As Integer
        Dim Box55 As Integer
        Dim Box56 As Integer
        Dim Box57 As Integer
        Dim Box58 As Integer

        'check to see if units are seconds
        If CheckBox5.Checked = True Then

            'SECONDS:

            'LABEL8

            'get numbers from textbox2
            Box51 = TextBox2.Text
            'do calculations for label8
            Box51 = Box51 / 30
            'print numbers to label8
            Label8.Text = Box51

            'LABEL9

            'get numbers from textbox2
            Box52 = TextBox2.Text
            'do calculations for label9
            'none
            'print numbers to label9
            Label9.Text = Box52

            'MINUTES:

            'LABEL12

            'get numbers from textbox2
            Box53 = TextBox2.Text
            'do calculations for label12
            Box53 = Box53 / 1800
            'print numbers to label12
            Label12.Text = Box53

            'LABEL13

            'get numbers from textbox2
            Box54 = TextBox2.Text
            'do calculations for label13
            Box54 = Box54 / 60
            'print numbers to label13
            Label13.Text = Box54

            'HOURS:

            'LABEL16

            'get numbers from textbox2
            Box55 = TextBox2.Text
            'do calculations for label16
            Box55 = Box55 / 108000
            'print numbers to label16
            Label16.Text = Box55

            'LABEL17

            'get numbers from textbox2
            Box56 = TextBox2.Text
            'do calculations for label17
            Box56 = Box56 / 3600
            'print numbers to label17
            Label17.Text = Box56

            'DAYS:

            'LABEL20

            'get numbers from textbox2
            Box57 = TextBox2.Text
            'do calculations for label20
            Box57 = Box57 / 2592000
            'print numbers to label20
            Label20.Text = Box57

            'LABEL21

            'get numbers from textbox2
            Box58 = TextBox2.Text
            'do calculations for label21
            Box58 = Box58 / 86400
            'print numbers to label21
            Label21.Text = Box58


        End If

        Dim Box61 As Integer
        Dim Box62 As Integer
        Dim Box63 As Integer
        Dim Box64 As Integer
        Dim Box65 As Integer
        Dim Box66 As Integer
        Dim Box67 As Integer
        Dim Box68 As Integer

        'check to see if units are minutes
        If CheckBox6.Checked = True Then

            'SECONDS:

            'LABEL8

            'get numbers from textbox2
            Box61 = TextBox2.Text
            'do calculations for label8
            Box61 = Box61 * 2
            'print numbers to label8
            Label8.Text = Box61

            'LABEL9

            'get numbers from textbox2
            Box62 = TextBox2.Text
            'do calculations for label9
            Box62 = Box62 * 60
            'print numbers to label9
            Label9.Text = Box62

            'MINUTES:

            'LABEL12

            'get numbers from textbox2
            Box63 = TextBox2.Text
            'do calculations for label12
            Box63 = Box63 / 30
            'print numbers to label12
            Label12.Text = Box63

            'LABEL13

            'get numbers from textbox2
            Box64 = TextBox2.Text
            'do calculations for label13
            '
            'print numbers to label13
            Label13.Text = Box64

            'HOURS:

            'LABEL16

            'get numbers from textbox2
            Box65 = TextBox2.Text
            'do calculations for label16
            Box65 = Box65 / 1800
            'print numbers to label16
            Label16.Text = Box65

            'LABEL17

            'get numbers from textbox2
            Box66 = TextBox2.Text
            'do calculations for label17
            Box66 = Box66 / 60
            'print numbers to label17
            Label17.Text = Box66

            'DAYS:

            'LABEL20

            'get numbers from textbox2
            Box67 = TextBox2.Text
            'do calculations for label20
            Box67 = Box67 / 43200
            'print numbers to label20
            Label20.Text = Box67

            'LABEL21

            'get numbers from textbox2
            Box68 = TextBox2.Text
            'do calculations for label21
            Box68 = Box68 / 1440
            'print numbers to label21
            Label21.Text = Box68

        End If

        Dim Box71 As Integer
        Dim Box72 As Integer
        Dim Box73 As Integer
        Dim Box74 As Integer
        Dim Box75 As Integer
        Dim Box76 As Integer
        Dim Box77 As Integer
        Dim Box78 As Integer

        'check to see if units are hours
        If CheckBox7.Checked = True Then

            'SECONDS:

            'LABEL8

            'get numbers from textbox2
            Box71 = TextBox2.Text
            'do calculations for label8
            Box71 = Box71 * 120
            'print numbers to label8
            Label8.Text = Box71

            'LABEL9

            'get numbers from textbox2
            Box72 = TextBox2.Text
            'do calculations for label9
            Box72 = Box72 * 3600
            'print numbers to label9
            Label9.Text = Box72

            'MINUTES:

            'LABEL12

            'get numbers from textbox2
            Box73 = TextBox2.Text
            'do calculations for label12
            Box73 = Box73 * 2
            'print numbers to label12
            Label12.Text = Box73

            'LABEL13

            'get numbers from textbox2
            Box74 = TextBox2.Text
            'do calculations for label13
            Box74 = Box74 * 60
            'print numbers to label13
            Label13.Text = Box74

            'HOURS:

            'LABEL16

            'get numbers from textbox2
            Box75 = TextBox2.Text
            'do calculations for label16
            Box75 = Box75 / 30
            'print numbers to label16
            Label16.Text = Box75

            'LABEL17

            'get numbers from textbox2
            Box76 = TextBox2.Text
            'do calculations for label17
            'none
            'print numbers to label17
            Label17.Text = Box76

            'DAYS:

            'LABEL20

            'get numbers from textbox2
            Box77 = TextBox2.Text
            'do calculations for label20
            Box77 = Box77 / 720
            'print numbers to label20
            Label20.Text = Box77

            'LABEL21

            'get numbers from textbox2
            Box78 = TextBox2.Text
            'do calculations for label21
            Box78 = Box78 / 24
            'print numbers to label21
            Label21.Text = Box78

        End If

        Dim Box81 As Integer
        Dim Box82 As Integer
        Dim Box83 As Integer
        Dim Box84 As Integer
        Dim Box85 As Integer
        Dim Box86 As Integer
        Dim Box87 As Integer
        Dim Box88 As Integer

        'check to see if units are days
        If CheckBox8.Checked = True Then

            'SECONDS:

            'LABEL8

            'get numbers from textbox2
            Box81 = TextBox2.Text
            'do calculations for label8
            Box81 = Box81 * 2880
            'print numbers to label8
            Label8.Text = Box81

            'LABEL9

            'get numbers from textbox2
            Box82 = TextBox2.Text
            'do calculations for label9
            Box82 = Box82 * 86400
            'print numbers to label9
            Label9.Text = Box82

            'MINUTES:

            'LABEL12

            'get numbers from textbox2
            Box83 = TextBox2.Text
            'do calculations for label12
            Box83 = Box83 * 48
            'print numbers to label12
            Label12.Text = Box83

            'LABEL13

            'get numbers from textbox2
            Box84 = TextBox2.Text
            'do calculations for label13
            Box84 = Box84 * 1440
            'print numbers to label13
            Label13.Text = Box84

            'HOURS:

            'LABEL16

            'get numbers from textbox2
            Box85 = TextBox2.Text
            'do calculations for label16
            Box85 = Box85 / 1.25
            'print numbers to label16
            Label16.Text = Box85

            'LABEL17

            'get numbers from textbox2
            Box86 = TextBox2.Text
            'do calculations for label17
            Box86 = Box86 * 24
            'print numbers to label17
            Label17.Text = Box86

            'DAYS:

            'LABEL20
            Box87 = TextBox2.Text
            'do calculaiotns for label20
            Box87 = Box87 / 30
            'print numbers to label20
            Label20.Text = Box87

            'LABEL21

            Box88 = TextBox2.Text
            'do calculations for label20
            'none
            'print numbers to label20
            Label21.Text = Box88

        End If
    End Sub
End Class
